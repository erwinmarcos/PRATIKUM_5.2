# praktikum-5.2
praktikum 5
